<nav>
    <ul class="nav nav-tabs">
        <li>
            <a class="nav-link" href="<?php echo site_url();?>">Home</a>
        </li>
        <li>
            <a class="nav-link" href="<?php echo site_url('home/records');?>">Records</a>
        </li>
        <li>
            <a class="nav-link" href="<?php echo site_url('home/create');?>">Add</a>
        </li>
        <li>
            <a class="nav-link" href="<?php echo site_url('home');?>">Link</a>
        </li>
    </ul>
</nav>